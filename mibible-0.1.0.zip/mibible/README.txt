mibible README
======================

1. about mibible
  Please see http://code.google.com/p/mibible/


2. release note

  2008/10/20 ver 0.1.0 release
    Issues Summary
         1 MIBファイルをドラッグ&ドロップすることでMIBブラウザを開きたい
         2 MIBツリーの要素にアイコンを設定したい
         3 オブジェクト名で検索したい
         4 OIDで検索したい
         5 ツリー表示文字列の可読性向上
         6 parserとbrowserの分離
         9 parserとprinterの分離
        11 mibibleパッケージの取得(Task)
        14 ウィンドウサイズ変更時にツリーのレイアウトが崩れる
