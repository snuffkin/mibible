mibible browser README
======================

  Please see http://code.google.com/p/mibible/

