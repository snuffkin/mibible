package jp.gr.java_conf.tsukano.snmpfreak.agent;

public class AgentEntry
{
	/** �z�X�g�� */
	private String hostname;
	/** IP�A�h���X */
	private String ipAddress;
	/** �ғ���� */
	private AgentStatus status;
	
	
	/**
	 * @return the hostname
	 */
	public String getHostname() {
		return hostname;
	}
	/**
	 * @param hostname the hostname to set
	 */
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	/**
	 * @return the ipAddress
	 */
	public String getIpAddress() {
		return ipAddress;
	}
	/**
	 * @param ipAddress the ipAddress to set
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	/**
	 * @return the status
	 */
	public AgentStatus getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(AgentStatus status) {
		this.status = status;
	}
	
}
