package jp.gr.java_conf.tsukano.snmpfreak.agent;

public class AgentTemplate
{
	/** �e���v���[�g�� */
	private final String name;
	/** �e���v���[�g�^�C�v */
	private final AgentTemplateType type;
	/**
	 * �e���v���[�g�t�@�C��
	 * AgentTemplateType.MIBS�̂Ƃ���";"�ŋ�؂��ĕ����̃t�@�C������ׂ�
	 */
	private String file;
	

	public AgentTemplate(String name, AgentTemplateType type)
	{
		this.name = name;
		this.type = type;
	}
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @return the type
	 */
	public AgentTemplateType getType() {
		return type;
	}

	/**
	 * @return the file
	 */
	public String getFile() {
		return file;
	}
	
	/**
	 * @return the files
	 */
	public String[] getFiles() {
		return file.split(";");
	}

	/**
	 * @param file the file to set
	 */
	public void setFile(String file) {
		this.file = file;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj)
	{
		if (obj instanceof AgentTemplate)
		{
			AgentTemplate target = (AgentTemplate) obj;
			return this.getName().equals(target.getName());
		}
		return false;
	}
}
