package jp.gr.java_conf.tsukano.snmpfreak.studio;

import org.eclipse.jface.action.GroupMarker;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;
import org.eclipse.ui.application.ActionBarAdvisor;
import org.eclipse.ui.application.IActionBarConfigurer;

public class ApplicationActionBarAdvisor extends ActionBarAdvisor {

	private IWorkbenchWindow window;
	private IWorkbenchAction exitAction;
	
    public ApplicationActionBarAdvisor(IActionBarConfigurer configurer) {
        super(configurer);
    }

    protected void makeActions(IWorkbenchWindow window)
    {
    	this.window = window;
    	exitAction = ActionFactory.QUIT.create(window);
    	register(exitAction);
    }

    protected void fillMenuBar(IMenuManager menuBar)
    {
    	// create File menu
    	MenuManager file = new MenuManager("&File", IWorkbenchActionConstants.M_FILE);
    	file.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
    	file.add(new Separator());
    	file.add(exitAction);
    	
    	// create Agent menu
    	MenuManager agent = new MenuManager("&Agent", "agent");
    	agent.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
    	
    	// create grobal menu
    	menuBar.add(file);
//    	menuBar.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
    	menuBar.add(agent);
//    	menuBar.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
    }
    
}
