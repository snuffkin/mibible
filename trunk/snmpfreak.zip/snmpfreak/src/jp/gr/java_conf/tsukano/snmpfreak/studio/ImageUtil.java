package jp.gr.java_conf.tsukano.snmpfreak.studio;

import java.net.URL;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.swt.graphics.Image;

public class ImageUtil {

	/**
	 * �摜�̃��W�X�g��
	 */
	private static ImageRegistry registry
	    = Activator.getDefault().getImageRegistry();

	/** �摜���i�[����Ă��郋�[�g�p�X */
	public static final String ICONS = "icons/"; //$NON-NLS-1$

	private static ImageDescriptor getImageDesc(String path)
	{
		URL url = FileLocator.find(Activator.getDefault().getBundle(),
				                   new Path(path), null);
		ImageDescriptor desc = ImageDescriptor.createFromURL(url);
		registry.put(path, desc);
		return desc;
	}

	// TODO ����ɂ���ȃ��\�b�h����炸�ɁA���U�@�ŋL�q���邱��
	public static Image getImage(String path) {
		getImageDesc(path);
		return registry.get(path);
	}
}
