/**
 * 
 */
package jp.gr.java_conf.tsukano.snmpfreak.studio.agentview;

import jp.gr.java_conf.tsukano.snmpfreak.studio.mibtreeview.MibTreeLabelProvider;

import org.eclipse.jface.viewers.CheckboxTreeViewer;
import org.eclipse.jface.viewers.TreeNodeContentProvider;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

/**
 * @author tsukano
 *
 */
public class AgentView extends ViewPart
{
	public static final String ID = "jp.gr.java_conf.tsukano.snmpfreak.studio.agentview";

	private CheckboxTreeViewer viewer;
	
	/**
	 * 
	 */
	public AgentView() {
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#createPartControl(org.eclipse.swt.widgets.Composite)
	 */
	@Override
	public void createPartControl(Composite parent)
	{
		// �r���[�ɍ��킹�ĉ����Əc����ω�������GridData
		GridData hv_fill_data = new GridData();
		hv_fill_data.horizontalAlignment = GridData.FILL;
		hv_fill_data.grabExcessHorizontalSpace = true;
		hv_fill_data.verticalAlignment = GridData.FILL;
		hv_fill_data.grabExcessVerticalSpace = true;
		hv_fill_data.horizontalIndent = 0;

		// TreeViewer�̐ݒ�
		viewer = new CheckboxTreeViewer(parent, SWT.MULTI | SWT.H_SCROLL
				| SWT.V_SCROLL | SWT.BORDER);
		viewer.setContentProvider(new TreeNodeContentProvider());
		viewer.setLabelProvider(new MibTreeLabelProvider());
		viewer.getTree().setLayoutData(hv_fill_data);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#setFocus()
	 */
	@Override
	public void setFocus() {
		// TODO Auto-generated method stub

	}

}
