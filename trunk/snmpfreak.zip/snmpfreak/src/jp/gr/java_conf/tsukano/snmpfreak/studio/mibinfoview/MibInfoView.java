/**
 * 
 */
package jp.gr.java_conf.tsukano.snmpfreak.studio.mibinfoview;

import net.percederberg.mibble.MibSymbol;

import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.TreeNode;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.part.ViewPart;

/**
 * @author tsukano
 *
 */
public class MibInfoView extends ViewPart
{
	public static final String ID = "jp.gr.java_conf.tsukano.snmpfreak.studio.mibinfoview";
	
	private Text text;
	
	private ISelectionListener listener = new ISelectionListener()
	{
		public void selectionChanged(IWorkbenchPart part, ISelection selection)
		{
			if (selection instanceof IStructuredSelection)
			{
				Object[] models = ((IStructuredSelection) selection).toArray();
				if (models.length == 0)
				{
					MibInfoView.this.text.setText("MIB Tree is not selected.");
					return;
				}
				
				if (models[0] instanceof TreeNode)
				{
					TreeNode node = (TreeNode) models[0];
					Object obj = node.getValue();
					if (obj instanceof MibSymbol)
					{
						MibSymbol symbol = (MibSymbol) obj;
						MibInfoView.this.text.setText(symbol.toString());
						return;
					}
				}
			}
			MibInfoView.this.text.setText("You don't select MibValueSymbol in MIB Tree.");
		}
	};
	
	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#createPartControl(org.eclipse.swt.widgets.Composite)
	 */
	@Override
	public void createPartControl(Composite parent)
	{
		// �X�N���[���\�ȃR���|�W�b�g���쐬
		ScrolledComposite scrollComposite = new ScrolledComposite(parent, SWT.V_SCROLL | SWT.H_SCROLL);
		// �X�N���[���\�ȃR���|�W�b�g��e�Ƃ���R���|�W�b�g���쐬����
		Composite composite = new Composite(scrollComposite, SWT.NONE);
		composite.setLayout(new FillLayout());

		// �\������e�L�X�g�̍쐬
		text = new Text(composite,
				        SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL | SWT.READ_ONLY | SWT.BORDER);
		text.setBackground(Display.getDefault().getSystemColor(SWT.COLOR_WHITE));
		text.setEnabled(true);

		// �X�N���[���o�[�ݒ�
		scrollComposite.setExpandHorizontal(true);
		scrollComposite.setExpandVertical(true);
		scrollComposite.setContent(composite);
		scrollComposite.setMinSize(composite.computeSize(SWT.DEFAULT, SWT.DEFAULT)); 
		
		// SelectionListener��o�^
		getSite().getPage().addSelectionListener(this.listener);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#setFocus()
	 */
	@Override
	public void setFocus()
	{
		// TODO Auto-generated method stub

	}
	
	@Override
	public void dispose()
	{
		// SelectionListener���폜
		getSite().getPage().removeSelectionListener(this.listener);
		
		super.dispose();
	}
}
