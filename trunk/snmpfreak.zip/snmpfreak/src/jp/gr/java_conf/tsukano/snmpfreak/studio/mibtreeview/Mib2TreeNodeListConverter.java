package jp.gr.java_conf.tsukano.snmpfreak.studio.mibtreeview;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.percederberg.mibble.MarkerMibNode;
import net.percederberg.mibble.Mib;
import net.percederberg.mibble.MibSymbol;
import net.percederberg.mibble.MibValueSymbol;

import org.eclipse.jface.viewers.TreeNode;

public class Mib2TreeNodeListConverter
{
	/** �ϊ�����Mib */
	private Mib mib;
	/** �ϊ�����Mib */
	private TreeNode[] treeNodeList;
	/** MibSymbol�ɑΉ�����TreeNode������HashMap */
	private Map<MibSymbol, TreeNode> selfMap;
	
	public Mib2TreeNodeListConverter(Mib mib)
	{
		this.mib = mib;
	}
	
	public TreeNode[] getTeeNodeList()
	{
		return treeNodeList;
	}
	
	public Map<MibSymbol, TreeNode> getSymbolMap()
	{
		return selfMap;
	}
	
	public void convert()
	{
		// MibSymbol�ɑΉ�����TreeNode
		selfMap = new HashMap<MibSymbol, TreeNode>();
		// MibSymbol�ɑΉ�����qTreeNode
		Map<MibSymbol, List<TreeNode>> chilrenMap = new HashMap<MibSymbol, List<TreeNode>>();
		
		// create root
		String mibName = mib.getName();
		// TODO�@������mib���w�肵�Ȃ�����
//		MibSymbol rootSymbol = new MarkerMibNode(mib, mibName, null);
		MibSymbol rootSymbol = new MarkerMibNode(null, mibName, null);
		TreeNode rootNode = new TreeNode(rootSymbol);
		selfMap.put(rootSymbol, rootNode);
		chilrenMap.put(rootSymbol, new ArrayList<TreeNode>());
		
		// create selfMap
		Iterator iterator = mib.getAllSymbols().iterator();
		while (iterator.hasNext())
		{
			Object obj = iterator.next();
			if (obj instanceof MibSymbol)
			{
				MibSymbol symbol = (MibSymbol) obj;
				selfMap.put(symbol, new TreeNode(symbol));
				chilrenMap.put(symbol, new ArrayList<TreeNode>());
				// TODO
//				System.out.println("add selfMap:" + symbol.toString());
			}
		}
		
		// create chilrenMap
		Iterator iterator2 = mib.getAllSymbols().iterator();
		while (iterator2.hasNext())
		{
			Object obj = iterator2.next();
			if (obj instanceof MibValueSymbol)
			{
				MibValueSymbol selfSymbol = (MibValueSymbol) obj;
				MibSymbol parentSymbol = selfSymbol.getParent();
				if (parentSymbol == null)
				{
					parentSymbol = rootSymbol;
				}
				// TODO
//				System.out.println("selfMap:" + selfSymbol.toString());
//						           + ", parentSymbol:" + parentSymbol.toString());
				
				// TreeNode��parent��ݒ肷��
				TreeNode selfTreeNode = selfMap.get(selfSymbol);
				TreeNode parentTreeNode = selfMap.get(parentSymbol);
				if (parentTreeNode == null)
				{
					parentTreeNode = rootNode;
					parentSymbol = rootSymbol;
				}
				selfTreeNode.setParent(parentTreeNode);
				
				// parent��children��ݒ肷��(���X�g���̂݁B���ۂɂ͂����ł͂܂��ݒ肵�Ă��Ȃ�)
				List<TreeNode> childrenOfParent = chilrenMap.get(parentSymbol);
				if (childrenOfParent != null)
				{
					childrenOfParent.add(selfTreeNode);
				}
				
/**				
				MibValueSymbol[] childrenSymbol = selfSymbol.getChildren();
				List<TreeNode> chilrenTreeNodeList = new ArrayList<TreeNode>();
				for (MibValueSymbol childSymbol : childrenSymbol)
				{
					TreeNode childTreeNode = selfMap.get(childSymbol);
					chilrenTreeNodeList.add(childTreeNode);
				}
				TreeNode[] chidrenTreeNode
				    = chilrenTreeNodeList.toArray(new TreeNode[chilrenTreeNodeList.size()]);
				selfTreeNode.setChildren(chidrenTreeNode);
*/
			}
		}
		
		// parent��children��ݒ肷��
		Iterator iterator3 = chilrenMap.keySet().iterator();
		while (iterator3.hasNext())
		{
			Object obj = iterator3.next();
			if (obj instanceof MibSymbol)
			{
				MibSymbol selfSymbol = (MibSymbol) obj;
				List<TreeNode> chilrenTreeNodeList = chilrenMap.get(selfSymbol);
				TreeNode[] chidrenTreeNode
			    = chilrenTreeNodeList.toArray(new TreeNode[chilrenTreeNodeList.size()]);
				
				TreeNode selfTreeNode = selfMap.get(selfSymbol);
				selfTreeNode.setChildren(chidrenTreeNode);
			}
		}
//		TreeNode[] nodeList = selfMap.values().toArray(new TreeNode[selfMap.size()]);
//		return nodeList;

//		MibValueSymbol rootSymbol = mib.getRootSymbol();
//		TreeNode rootTreeNode = selfMap.get(rootSymbol);
		treeNodeList = new TreeNode[]{rootNode};
	}
}
