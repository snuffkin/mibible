/**
 * 
 */
package jp.gr.java_conf.tsukano.snmpfreak.studio.mibtreeview;

import org.eclipse.jface.viewers.TreeNode;
import org.eclipse.jface.viewers.TreeNodeContentProvider;

/**
 * @author tsukano
 *
 */
//public class MibTreeContentProvider implements ITreeContentProvider {
public class MibTreeContentProvider extends TreeNodeContentProvider {

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.ITreeContentProvider#getChildren(java.lang.Object)
	 */
	public Object[] getChildren(Object parentElement)
	{
		if (parentElement instanceof TreeNode)
		{
			TreeNode node = (TreeNode) parentElement;
			return node.getChildren();
		}
		return null;
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.ITreeContentProvider#getParent(java.lang.Object)
	 */
	public Object getParent(Object element)
	{
		if (element instanceof TreeNode)
		{
			TreeNode node = (TreeNode) element;
			return node.getParent();
		}
		return null;
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.ITreeContentProvider#hasChildren(java.lang.Object)
	 */
	public boolean hasChildren(Object element)
	{
		if (element instanceof TreeNode)
		{
			TreeNode node = (TreeNode) element;
			return node.hasChildren();
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IStructuredContentProvider#getElements(java.lang.Object)
	 */
/**
	public Object[] getElements(Object inputElement)
	{
		return getChildren(inputElement);
	}
*/	
	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IContentProvider#dispose()
	 */
/**
	public void dispose() {
		// TODO Auto-generated method stub

	}
*/
	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IContentProvider#inputChanged(org.eclipse.jface.viewers.Viewer, java.lang.Object, java.lang.Object)
	 */
/**
	public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
		// TODO Auto-generated method stub

	}
*/
}
