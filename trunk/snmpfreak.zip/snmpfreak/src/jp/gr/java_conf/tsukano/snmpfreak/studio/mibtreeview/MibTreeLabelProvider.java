/**
 * 
 */
package jp.gr.java_conf.tsukano.snmpfreak.studio.mibtreeview;

import net.percederberg.mibble.MibSymbol;
import net.percederberg.mibble.MibType;
import net.percederberg.mibble.MibValue;
import net.percederberg.mibble.MibValueSymbol;
import net.percederberg.mibble.snmp.SnmpAccess;
import net.percederberg.mibble.snmp.SnmpNotificationGroup;
import net.percederberg.mibble.snmp.SnmpNotificationType;
import net.percederberg.mibble.snmp.SnmpObjectGroup;
import net.percederberg.mibble.snmp.SnmpObjectType;
import net.percederberg.mibble.type.SequenceOfType;
import net.percederberg.mibble.type.SequenceType;
import net.percederberg.mibble.value.ObjectIdentifierValue;

import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.TreeNode;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PlatformUI;

/**
 * @author tsukano
 *
 */
public class MibTreeLabelProvider implements ILabelProvider {

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.ILabelProvider#getImage(java.lang.Object)
	 */
	public Image getImage(Object element)
	{
		String imageKey = ISharedImages.IMG_OBJ_ELEMENT;
		if (element instanceof TreeNode)
		{
			TreeNode node = (TreeNode) element;
			Object value = node.getValue();
			
			if (   value != null
				&& value instanceof MibValueSymbol)
			{
				MibValueSymbol symbol = (MibValueSymbol) value;
				Image image = convertMibValueSymbolToIcon(symbol);
				if (image != null)
				{
					return image;
				}
			}
			
			// Other case
			boolean hasChildren = node.hasChildren();
			if (hasChildren == true)
			{
				imageKey = ISharedImages.IMG_OBJ_FOLDER;
			}
			else
			{
				imageKey = ISharedImages.IMG_OBJ_FILE;
			}
			return PlatformUI.getWorkbench().getSharedImages().getImage(imageKey);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.ILabelProvider#getText(java.lang.Object)
	 */
	public String getText(Object element)
	{
		if (element instanceof TreeNode)
		{
			TreeNode node = (TreeNode) element;
			MibSymbol symbol = (MibSymbol) node.getValue();
			if (symbol instanceof MibValueSymbol)
			{
				MibValueSymbol targetSymbol = (MibValueSymbol) symbol;
				MibValue value = targetSymbol.getValue();
				if (value instanceof ObjectIdentifierValue)
				{
					ObjectIdentifierValue oid = (ObjectIdentifierValue) value;
					return "[" + oid.getValue() + "] " + symbol.getName();
				}
			}
			return symbol.getName();
		}
		return "irregular value";
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IBaseLabelProvider#addListener(org.eclipse.jface.viewers.ILabelProviderListener)
	 */
	public void addListener(ILabelProviderListener listener) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IBaseLabelProvider#dispose()
	 */
	public void dispose() {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IBaseLabelProvider#isLabelProperty(java.lang.Object, java.lang.String)
	 */
	public boolean isLabelProperty(Object element, String property) {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IBaseLabelProvider#removeListener(org.eclipse.jface.viewers.ILabelProviderListener)
	 */
	public void removeListener(ILabelProviderListener listener) {
		// TODO Auto-generated method stub

	}

    /**
     * convert MibNode To Tree Icon for Rendering.
     * 
     * @param symbol MibValueSymbol
     * @return Image
     */
    private Image convertMibValueSymbolToIcon(MibValueSymbol symbol)
    {
    	// MibValueSymbol��null�̏ꍇ��null��Ԃ�
		if (symbol == null)
		{
   	    	return null;
   	    }
			
    	// MibType��null�̏ꍇ��null��Ԃ�
		MibType type = symbol.getType();
   	    if (type == null)
   	    {
   	    	return null;
   	    }
   	    
    	// MibValue��null�̏ꍇ��null��Ԃ�
   	    MibValue value = symbol.getValue();
   	    if (value == null)
   	    {
   	    	return null;
   	    }
   	    	
        if (type instanceof SnmpNotificationType)
        {
        	// NotificationType
            return MibTreeView.Image_SnmpNotificationType;
        }
        else if (type instanceof SnmpObjectType)
        {
        	// ObjectType
       	    SnmpObjectType objectType = (SnmpObjectType) type;
     	    SnmpAccess access = objectType.getAccess();
     	    MibType syntax = objectType.getSyntax();
     	    
     	    // SequenceType�ASequenceOfType��syntax�ŃA�C�R����ω�������
        	if (syntax instanceof SequenceType)
            {
        		// SequenceType
     	    	return MibTreeView.Image_SnmpObjectType_SequenceType;
            }
        	else if (syntax instanceof SequenceOfType)
        	{
        		// SequenceOfType
     	    	return MibTreeView.Image_SnmpObjectType_SequenceOfType;
        	}
        	
     	    // ObjectType��accessible�ŃA�C�R����ω�������
     	    if (access == SnmpAccess.NOT_ACCESSIBLE)
     	    {
     	    	// not-accessible
     	    	return MibTreeView.Image_SnmpObjectType_na;
     	    }
     	    else if (access == SnmpAccess.READ_CREATE)
     	    {
     	    	// read-create
     	    	return MibTreeView.Image_SnmpObjectType_rc;
     	    }
     	    else if (access == SnmpAccess.READ_ONLY)
     	    {
     	    	// read-only
     	    	return MibTreeView.Image_SnmpObjectType_ro;
     	    }
     	    else if (access == SnmpAccess.READ_WRITE)
     	    {
     	    	// read-only
     	    	return MibTreeView.Image_SnmpObjectType_rw;
     	    }
     	    else
     	    {
     	    	// default
     	    	return MibTreeView.Image_SnmpObjectType;
     	    }
        }
        else if (type instanceof SnmpNotificationGroup)
        {
    		// SnmpNotificationGroup
 	    	return MibTreeView.Image_SnmpNotificationGroup;
        }
        else if (type instanceof SnmpObjectGroup)
        {
    		// SnmpObjectGroup
 	    	return MibTreeView.Image_SnmpObjectGroup;
        }
        	
		return null;
    }
}
