/**
 * 
 */
package jp.gr.java_conf.tsukano.snmpfreak.studio.mibtreeview;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.gr.java_conf.tsukano.snmpfreak.studio.ImageUtil;
import jp.gr.java_conf.tsukano.snmpfreak.studio.mibinfoview.MibInfoView;

import net.percederberg.mibble.MarkerMibNode;
import net.percederberg.mibble.Mib;
import net.percederberg.mibble.MibLoaderException;
import net.percederberg.mibble.MibSymbol;
import net.percederberg.mibble.browser.MibTreeBuilder;

import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeNode;
import org.eclipse.jface.viewers.TreeNodeContentProvider;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.dnd.DND;
import org.eclipse.swt.dnd.DropTarget;
import org.eclipse.swt.dnd.DropTargetAdapter;
import org.eclipse.swt.dnd.DropTargetEvent;
import org.eclipse.swt.dnd.DropTargetListener;
import org.eclipse.swt.dnd.FileTransfer;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

/**
 * @author tsukano
 *
 */
public class MibTreeView extends ViewPart
{
	public static final String ID = "jp.gr.java_conf.tsukano.snmpfreak.studio.mibtreeview";

	/** MibTree��\������TreeViewer */
	protected TreeViewer viewer;
	
    /** Name Search Label */
	protected Label nameSearchLabel;
    /** Name Search Text */
	protected Text nameSearchText;
    /** Name Search Button */
	protected Button nameSearchButton;

    /** OID Search Label */
	protected Label oidSearchLabel;
    /** OID Search Text */
	protected Text oidSearchText;
    /** OID Search Button */
	protected Button oidSearchButton;

//	protected MibTreeContentProvider contentProvider;
	
	/** MibTree�ɕ\������A�C�R��(SnmpNotificationType) */
	public static final Image Image_SnmpNotificationType
	    = ImageUtil.getImage(ImageUtil.ICONS + "SnmpNotificationType.gif");
	
	/** MibTree�ɕ\������A�C�R��(SnmpObjectType) */
	public static final Image Image_SnmpObjectType
	    = ImageUtil.getImage(ImageUtil.ICONS + "SnmpObjectType.gif");
	
	/** MibTree�ɕ\������A�C�R��(SnmpObjectType_na) */
	public static final Image Image_SnmpObjectType_na
	    = ImageUtil.getImage(ImageUtil.ICONS + "SnmpObjectType_na.gif");
	
	/** MibTree�ɕ\������A�C�R��(SnmpObjectType_rc) */
	public static final Image Image_SnmpObjectType_rc
	    = ImageUtil.getImage(ImageUtil.ICONS + "SnmpObjectType_rc.gif");
	
	/** MibTree�ɕ\������A�C�R��(SnmpObjectType_ro) */
	public static final Image Image_SnmpObjectType_ro
	    = ImageUtil.getImage(ImageUtil.ICONS + "SnmpObjectType_ro.gif");
	
	/** MibTree�ɕ\������A�C�R��(SnmpObjectType_rw) */
	public static final Image Image_SnmpObjectType_rw
	    = ImageUtil.getImage(ImageUtil.ICONS + "SnmpObjectType_rw.gif");
	
	/** MibTree�ɕ\������A�C�R��(SnmpObjectType_SequenceType) */
	public static final Image Image_SnmpObjectType_SequenceType
	    = ImageUtil.getImage(ImageUtil.ICONS + "SnmpObjectType_SequenceType.gif");
	
	/** MibTree�ɕ\������A�C�R��(SnmpObjectType_SequenceType) */
	public static final Image Image_SnmpObjectType_SequenceOfType
	    = ImageUtil.getImage(ImageUtil.ICONS + "SnmpObjectType_SequenceOfType.gif");
	
	/** MibTree�ɕ\������A�C�R��(SnmpNotificationGroup) */
	public static final Image Image_SnmpNotificationGroup
	    = ImageUtil.getImage(ImageUtil.ICONS + "SnmpNotificationGroup.gif");
	
	/** MibTree�ɕ\������A�C�R��(SnmpObjectGroup) */
	public static final Image Image_SnmpObjectGroup
	    = ImageUtil.getImage(ImageUtil.ICONS + "SnmpObjectGroup.gif");
	
	private List<Mib> loadedMibs = new ArrayList<Mib>();
	private List<TreeNode> loadedRoots = new ArrayList<TreeNode>();
	private Map<MibSymbol, TreeNode> symbolMap = new HashMap<MibSymbol, TreeNode>();


//	protected ICompilationUnit currentTree;

	
	
	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#createPartControl(org.eclipse.swt.widgets.Composite)
	 */
	@Override
	public void createPartControl(Composite parent)
	{
		// �r���[�ɍ��킹�ĉ�����ω�������GridData
		GridData h_fill_data = new GridData();
		h_fill_data.horizontalAlignment = GridData.FILL;
		h_fill_data.grabExcessHorizontalSpace = true;

		// �r���[�ɍ��킹�ĉ����Əc����ω�������GridData
		GridData hv_fill_data = new GridData();
		hv_fill_data.horizontalAlignment = GridData.FILL;
		hv_fill_data.grabExcessHorizontalSpace = true;
		hv_fill_data.verticalAlignment = GridData.FILL;
		hv_fill_data.grabExcessVerticalSpace = true;
		hv_fill_data.horizontalIndent = 0;

		//////////////////////////////
		// �r���[�̃��C�A�E�g�ݒ�
		//////////////////////////////
		GridLayout parentLayout = new GridLayout(1, false);
		parentLayout.horizontalSpacing = 0;
		parentLayout.marginBottom = 0;
		parentLayout.marginHeight = 0;
		parentLayout.marginLeft = 0;
		parentLayout.marginRight = 0;
		parentLayout.marginTop = 0;
		parentLayout.marginWidth = 0;
		parentLayout.verticalSpacing = 1;
		parent.setLayout(parentLayout);
		
		//////////////////////////////
		// �����̈�̐ݒ�
		//////////////////////////////
		
		// �����̈�̃��C�A�E�g�ݒ�
		Composite searchComposite = new Composite(parent, SWT.NULL);
		GridLayout searchCompositeLayout = new GridLayout(3, false);
		searchCompositeLayout.marginHeight = 0;
		searchCompositeLayout.verticalSpacing = 0;
		searchComposite.setLayout(searchCompositeLayout);
		searchComposite.setLayoutData(h_fill_data);
		
		// Name Search Label�̐ݒ�
		nameSearchLabel = new Label(searchComposite, SWT.SINGLE);
		nameSearchLabel.setText("Name");
		
		// Name Search Text�̐ݒ�
		nameSearchText = new Text(searchComposite, SWT.SINGLE | SWT.BORDER);
		nameSearchText.setLayoutData(h_fill_data);
		
		// Name Search Button�̐ݒ�
		nameSearchButton = new Button(searchComposite, SWT.PUSH);
		nameSearchButton.setText("Search");
        nameSearchButton.setToolTipText("Search by Name and Expand Tree");
		nameSearchButton.addSelectionListener(new SelectionAdapter()
		{
			public void widgetSelected(SelectionEvent event)
			{
				searchByName(nameSearchText.getText());
			}
		});
		
		// OID Search Label�̐ݒ�
		oidSearchLabel = new Label(searchComposite, SWT.SINGLE);
		oidSearchLabel.setText("OID");
		
		// OID Search Text�̐ݒ�
		oidSearchText = new Text(searchComposite, SWT.SINGLE | SWT.BORDER);
		oidSearchText.setLayoutData(h_fill_data);
		
		// OID Search Button�̐ݒ�
		oidSearchButton = new Button(searchComposite, SWT.PUSH);
		oidSearchButton.setText("Search");
		oidSearchButton.setToolTipText("Search by OID and Expand Tree");
		oidSearchButton.addSelectionListener(new SelectionAdapter()
		{
			public void widgetSelected(SelectionEvent event)
			{
				searchByOid(oidSearchText.getText());
			}
		});
		
		//////////////////////////////
		// �c���[�\���̈�̐ݒ�
		//////////////////////////////

		// TreeNodeContentProvider�̏�����
//		this.contentProvider = new MibTreeContentProvider();

		// TreeViewer�̐ݒ�
		viewer = new TreeViewer(parent, SWT.SINGLE | SWT.H_SCROLL
				| SWT.V_SCROLL | SWT.BORDER);
		viewer.setContentProvider(new TreeNodeContentProvider());
		viewer.setLabelProvider(new MibTreeLabelProvider());
		viewer.getTree().setLayoutData(hv_fill_data);
		
		viewer.addDropSupport(DND.DROP_MOVE | DND.DROP_COPY | DND.DROP_DEFAULT,
				new Transfer[]{FileTransfer.getInstance()},
				new DropTargetAdapter()
		{
			/* (non-Javadoc)
			 * @see org.eclipse.swt.dnd.DropTargetAdapter#drop(org.eclipse.swt.dnd.DropTargetEvent)
			 */
			@Override
			public void drop(DropTargetEvent event)
			{
				if (FileTransfer.getInstance().isSupportedType(event.currentDataType) == false)
				{
					return;
				}
				
				String[] files = (String[])event.data;
				for (String file : files)
				{
					try {
						loadMib(file);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (MibLoaderException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			
		});
		
		// SelectionProvider��MIBTree��o�^����
		getSite().setSelectionProvider(this.viewer);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#setFocus()
	 */
	@Override
	public void setFocus()
	{
		// TODO Auto-generated method stub

	}
	
    /**
     * Loads MIB file or URL.
     *
     * @param src            the MIB file or URL
     *
     * @throws IOException if the MIB file couldn't be found in the
     *             MIB search path
     * @throws MibLoaderException if the MIB file couldn't be loaded
     *             correctly
     */
    public void loadMib(String src)
        throws IOException, MibLoaderException
    {
        File file = new File(src);
        MibTreeBuilder  mb = MibTreeBuilder.getInstance();
        Mib mib = mb.loadMib(file);
        addData(mib);
    }
    
	private void addData(Mib mib)
	{
        // Check for already loaded MIB
        for (int index = 0; index < this.loadedMibs.size(); index++)
        {
            if (mib.getName().equals(this.loadedMibs.get(index).getName()))
            {
                return;
            }
        }

        // Mib����TreeNode�ɕϊ�����
        Mib2TreeNodeListConverter converter
            = new Mib2TreeNodeListConverter(mib);
        converter.convert();
        
        // �ϊ���̏����擾����
		TreeNode[] addedRootNode = converter.getTeeNodeList();
		Map<MibSymbol, TreeNode> addedSymbolMap = converter.getSymbolMap();
		
        // �ϊ���̏���ێ�����
        loadedMibs.add(mib);
        loadedRoots.add(addedRootNode[0]);
        symbolMap.putAll(addedSymbolMap);

        // Tree��\������
        TreeNode[] rootNodeList
            = loadedRoots.toArray(new TreeNode[loadedRoots.size()]);
		viewer.setInput(rootNodeList);
	}
	
	public void searchByName(String name)
	{
        viewer.getTree().setFocus();
		MibSymbol symbol = null;
		
		// Mib��񂩂�MibValueSymbol���擾����
		for (Mib mib : loadedMibs)
		{
			symbol = mib.getSymbol(name);
            if (symbol != null)
            {
            	break;
            }
		}
		selectSymbol(symbol);
	}
	
	public void searchByOid(String oid)
	{
        viewer.getTree().setFocus();
        MibSymbol symbol = null;
		
		// Mib��񂩂�MibSymbol���擾����
		for (Mib mib : loadedMibs)
		{
			symbol = mib.getSymbolByOid(oid);
            if (symbol != null)
            {
            	break;
            }
		}
		selectSymbol(symbol);
	}
	
	private void selectSymbol(MibSymbol symbol)
	{
		// MibSymbol��������Ȃ��ꍇ�́A�I����Ԃ��N���A����
        if (   symbol == null
        	|| symbolMap.get(symbol) == null)
        {
        	viewer.setSelection(null);
            return;
        }
        
        // MibTree��I����Ԃɂ���
        TreeNode treeNode = symbolMap.get(symbol);
        ISelection selection = new StructuredSelection(treeNode);
        viewer.setSelection(selection);
	}
	
	public void unloadMib()
	{
		ISelection selection = viewer.getSelection();
		if (selection instanceof IStructuredSelection)
		{
			Object[] models = ((IStructuredSelection) selection).toArray();
			if (models.length == 0)
			{
				// ���I�����͉������Ȃ�
				return;
			}
			
			if (models[0] instanceof TreeNode)
			{
				TreeNode node = (TreeNode) models[0];
				Object obj = node.getValue();
				if (obj instanceof MibSymbol)
				{
					MibSymbol symbol = (MibSymbol) obj;
					
					// Mib�����擾����
					String mibName;
					if (symbol instanceof MarkerMibNode)
					{
						mibName = symbol.getName();
					}
					else
					{
						mibName = symbol.getMib().getName();
					}
					
					for (Mib mib : loadedMibs)
					{
						if (mibName.equals(mib.getName()) == true)
						{
							// MibTreeBuilder����폜����
							MibTreeBuilder.getInstance().unloadMib(mibName);
							// Mib���X�g����폜����
							loadedMibs.remove(mib);
							// Mib��root���X�g����폜����
							for (TreeNode rootNode : loadedRoots)
							{
								MibSymbol rootSymbol = (MibSymbol) rootNode.getValue();
								if (rootSymbol.getName().equals(mib.getName()) == true)
								{
									loadedRoots.remove(rootNode);
									break;
								}
							}

							// Tree��\������
					        TreeNode[] rootNodeList
					            = loadedRoots.toArray(new TreeNode[loadedRoots.size()]);
							viewer.setInput(rootNodeList);

							// TODO symbol map������폜
							return;
						}
					}
				}
			}
		}
	}
}
