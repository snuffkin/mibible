/**
 * 
 */
package jp.gr.java_conf.tsukano.snmpfreak.studio.mibtreeview.actions;

import java.io.File;
import java.io.IOException;

import jp.gr.java_conf.tsukano.snmpfreak.studio.mibtreeview.MibTreeView;
import jp.gr.java_conf.tsukano.snmpfreak.studio.util.WorkbenchUtil;

import net.percederberg.mibble.Mib;
import net.percederberg.mibble.MibLoaderException;
import net.percederberg.mibble.browser.MibTreeBuilder;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;

/**
 * @author tsukano
 *
 */
public class LoadMibAction implements IWorkbenchWindowActionDelegate {

	private IWorkbenchWindow window;
	
	/* (non-Javadoc)
	 * @see org.eclipse.ui.IWorkbenchWindowActionDelegate#dispose()
	 */
	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.IWorkbenchWindowActionDelegate#init(org.eclipse.ui.IWorkbenchWindow)
	 */
	@Override
	public void init(IWorkbenchWindow window)
	{
		this.window = window;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.IActionDelegate#run(org.eclipse.jface.action.IAction)
	 */
	@Override
	public void run(IAction action)
	{
		FileDialog dialog = new FileDialog(this.window.getShell(), SWT.OPEN | SWT.MULTI);
		dialog.open();
		String [] files = dialog.getFileNames();
		
		if (files.length == 0)
		{
			return;
		}
		
        MibTreeView view = (MibTreeView) WorkbenchUtil.findView(MibTreeView.ID);
		String path = dialog.getFilterPath();
		for (int index = 0; index < files.length; index++)
		{
			String fullFileName = path + "\\" + files[index];
			// TODO
//			System.out.println(fullFileName);

			try {
		        view.loadMib(fullFileName);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (MibLoaderException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.IActionDelegate#selectionChanged(org.eclipse.jface.action.IAction, org.eclipse.jface.viewers.ISelection)
	 */
	@Override
	public void selectionChanged(IAction action, ISelection selection) {
		// TODO Auto-generated method stub

	}
    /**
     * Loads MIB file or URL.
     *
     * @param src            the MIB file or URL
     *
     * @throws IOException if the MIB file couldn't be found in the
     *             MIB search path
     * @throws MibLoaderException if the MIB file couldn't be loaded
     *             correctly
     */
    private void loadMib(String src)
        throws IOException, MibLoaderException
    {
        MibTreeView view = (MibTreeView) WorkbenchUtil.findView(MibTreeView.ID);
        view.loadMib(src);
    }
}
