package jp.gr.java_conf.tsukano.snmpfreak.studio.mibtreeview.actions;

import jp.gr.java_conf.tsukano.snmpfreak.studio.mibtreeview.MibTreeView;
import jp.gr.java_conf.tsukano.snmpfreak.studio.util.WorkbenchUtil;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;

public class UnloadMibAction implements IWorkbenchWindowActionDelegate
{

	private IWorkbenchWindow window;
	
	/* (non-Javadoc)
	 * @see org.eclipse.ui.IWorkbenchWindowActionDelegate#dispose()
	 */
	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.IWorkbenchWindowActionDelegate#init(org.eclipse.ui.IWorkbenchWindow)
	 */
	@Override
	public void init(IWorkbenchWindow window)
	{
		this.window = window;
	}

	@Override
	public void run(IAction action)
	{
        MibTreeView view = (MibTreeView) WorkbenchUtil.findView(MibTreeView.ID);
        view.unloadMib();
	}

	@Override
	public void selectionChanged(IAction action, ISelection selection) {
		// TODO Auto-generated method stub

	}
}
