package jp.gr.java_conf.tsukano.snmpfreak.studio.util;

import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

public class WorkbenchUtil
{
	public static IViewPart findView(String viewId)
	{
		IWorkbench workBench = PlatformUI.getWorkbench();
		IWorkbenchWindow window = workBench.getActiveWorkbenchWindow();
		IWorkbenchPage page = window.getActivePage();
	
    	try
    	{
			IViewPart view = page.showView(viewId);
			return view;
		}
    	catch (PartInitException ex)
    	{
			// TODO Auto-generated catch block
    		ex.printStackTrace();
    		return null;
		}
	}

}
