package net.percederberg.mibble;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.util.ArrayList;

import net.percederberg.grammatica.parser.ParserCreationException;
import net.percederberg.grammatica.parser.ParserLogException;
import net.percederberg.mibble.asn1.Asn1Parser;

public class MibSource
{

    /**
     * The MIB file. This variable is only set if the MIB is read
     * from file, or if the MIB name is known.
     */
    private File file = null;

    /**
     * The MIB URL location. This variable is only set if the MIB
     * is read from a URL.
     */
    private URL url = null;

    /**
     * The MIB reader. This variable is only set if the MIB
     * is read from an input stream.
     */
    private Reader input = null;

    /**
     * Creates a new MIB input source. The MIB will be read from
     * the specified file.
     *
     * @param file           the file to read from
     */
    public MibSource(File file) {
        this.file = file;
    }

    /**
     * Creates a new MIB input source. The MIB will be read from
     * the specified URL.
     *
     * @param url            the URL to read from
     */
    public MibSource(URL url) {
        this.url = url;
    }

    /**
     * Creates a new MIB input source. The MIB will be read from
     * the specified URL. This method also create a default file
     * from the specified MIB name in order to improve possible
     * error messages.
     *
     * @param name           the MIB name
     * @param url            the URL to read from
     */
    public MibSource(String name, URL url) {
        this(url);
        this.file = new File(name);
    }

    /**
     * Creates a new MIB input source. The MIB will be read from
     * the specified input reader. The input reader will be closed
     * after reading the MIB.
     *
     * @param input          the input stream to read from
     */
    public MibSource(Reader input) {
        this.input = input;
    }

    /**
     * Checks if this object is equal to another. This method
     * will only return true for another mib source object with
     * the same input source.
     *
     * @param obj            the object to compare with
     *
     * @return true if the object is equal to this, or
     *         false otherwise
     */
    public boolean equals(Object obj) {
        MibSource  src;

        if (obj instanceof MibSource) {
            src = (MibSource) obj;
            if (url != null) {
                return url.equals(src.url);
            } else if (file != null) {
                return file.equals(src.file);
            }
        }
        return false;
    }

    /**
     * Returns the hash code value for the object. This method is
     * reimplemented to fulfil the contract of returning the same
     * hash code for objects that are considered equal.
     *
     * @return the hash code value for the object
     *
     * @since 2.6
     */
    public int hashCode() {
        if (url != null) {
            return url.hashCode();
        } else if (file != null) {
            return file.hashCode();
        } else {
            return super.hashCode();
        }
    }

    /**
     * Returns the MIB file. If the MIB is loaded from URL this
     * file does not actually exist, but is used for providing a
     * unique reference to the MIB.
     *
     * @return the MIB file
     */
    public File getFile() {
        return file;
    }

    /**
     * Parses the MIB input source and returns the MIB modules
     * found. This method will read the MIB either from file, URL
     * or input stream.
     *
     * @param loader         the MIB loader to use for imports
     * @param log            the MIB log to use for errors
     *
     * @return the list of MIB modules created
     *
     * @throws IOException if the MIB couldn't be found
     * @throws MibLoaderException if the MIB couldn't be parsed
     *             or analyzed correctly
     */
    public ArrayList parseMib(MibLoader loader, MibLoaderLog log)
        throws IOException, MibLoaderException {

        Asn1Parser   parser;
        MibAnalyzer  analyzer;
        String       msg;

        // Open input stream
        if (input != null) {
            // Do nothing as input stream already setup
        } else if (url != null) {
            input = new InputStreamReader(url.openStream());
        } else {
            input = new FileReader(file);
        }

        // Parse input stream
        try {
            analyzer = new MibAnalyzer(file, loader, log);
            parser = new Asn1Parser(input, analyzer);
            parser.getTokenizer().setUseTokenList(true);
            parser.parse();
            return analyzer.getMibs();
        } catch (ParserCreationException e) {
            msg = "parser creation error in ASN.1 parser: " +
                  e.getMessage();
            log.addInternalError(file, msg);
            throw new MibLoaderException(log);
        } catch (ParserLogException e) {
            log.addAll(file, e);
            throw new MibLoaderException(log);
        }
    }
}
