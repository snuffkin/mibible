package jp.gr.java_conf.tsukano.snmpfreak.model;

import java.util.List;

public class NotificationType extends Variation
{
	private String status;
	private List<String> objects;

	
}
