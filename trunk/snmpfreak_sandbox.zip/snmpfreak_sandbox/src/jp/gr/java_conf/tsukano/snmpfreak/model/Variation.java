package jp.gr.java_conf.tsukano.snmpfreak.model;

public class Variation
{
	private String variation;
	private String syntax;
	private String writeSyntax;
	private String access;
	private String creation;
	private String description;
	private String oid;
	private String value;
}
