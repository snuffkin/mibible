/**
 * 
 */
package jp.gr.java_conf.tsukano.snmpfreak.studio.mibinfoview;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.ViewPart;

/**
 * @author tsukano
 *
 */
public class MibInfoView extends ViewPart
{
	public static final String ID = "jp.gr.java_conf.tsukano.snmpfreak.studio.mibinfoview";
	
	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#createPartControl(org.eclipse.swt.widgets.Composite)
	 */
	@Override
	public void createPartControl(Composite parent)
	{
		// �X�N���[���\�ȃR���|�W�b�g���쐬
		ScrolledComposite scrollComposite = new ScrolledComposite(parent, SWT.V_SCROLL | SWT.H_SCROLL);
		// �X�N���[���\�ȃR���|�W�b�g��e�Ƃ���R���|�W�b�g���쐬����
		Composite composite = new Composite(scrollComposite, SWT.NONE);
//		composite.setLayout(new GridLayout(1, false));
		composite.setLayout(new FillLayout());

		// �\������e�L�X�g�̍쐬
		Label label = new Label(composite, SWT.NONE);
		label.setText("Scrollable Composite View");
		label.setBackground(Display.getDefault().getSystemColor(SWT.COLOR_WHITE));
		label.setEnabled(true);

		// �X�N���[���o�[�ݒ�
		scrollComposite.setExpandHorizontal(true);
		scrollComposite.setExpandVertical(true);
		scrollComposite.setContent(composite);
		scrollComposite.setMinSize(composite.computeSize(SWT.DEFAULT, SWT.DEFAULT)); 
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#setFocus()
	 */
	@Override
	public void setFocus()
	{
		// TODO Auto-generated method stub

	}
}
