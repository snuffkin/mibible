/**
 * 
 */
package jp.gr.java_conf.tsukano.snmpfreak.studio.mibtreeview;

import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.TreeNode;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PlatformUI;

/**
 * @author tsukano
 *
 */
public class MibTreeLabelProvider implements ILabelProvider {

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.ILabelProvider#getImage(java.lang.Object)
	 */
	public Image getImage(Object element)
	{
		String imageKey = ISharedImages.IMG_OBJ_ELEMENT;
		if (element instanceof TreeNode)
		{
			TreeNode node = (TreeNode) element;
			SampleTreeModel model = (SampleTreeModel) node.getValue();
			
			if (model.getType() == 1)
			{
				imageKey = ISharedImages.IMG_OBJ_FOLDER;
			}
			else if (model.getType() == 2)
			{
				imageKey = ISharedImages.IMG_OBJ_FILE;
			}
			return PlatformUI.getWorkbench().getSharedImages().getImage(imageKey);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.ILabelProvider#getText(java.lang.Object)
	 */
	public String getText(Object element)
	{
		if (element instanceof TreeNode)
		{
			TreeNode node = (TreeNode) element;
			SampleTreeModel model = (SampleTreeModel) node.getValue();
			return model.getName();
		}
		return "irregular value";
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IBaseLabelProvider#addListener(org.eclipse.jface.viewers.ILabelProviderListener)
	 */
	public void addListener(ILabelProviderListener listener) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IBaseLabelProvider#dispose()
	 */
	public void dispose() {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IBaseLabelProvider#isLabelProperty(java.lang.Object, java.lang.String)
	 */
	public boolean isLabelProperty(Object element, String property) {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IBaseLabelProvider#removeListener(org.eclipse.jface.viewers.ILabelProviderListener)
	 */
	public void removeListener(ILabelProviderListener listener) {
		// TODO Auto-generated method stub

	}

}
