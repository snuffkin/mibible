/**
 * 
 */
package jp.gr.java_conf.tsukano.snmpfreak.studio.mibtreeview;

import org.eclipse.jface.viewers.TreeNode;
import org.eclipse.jface.viewers.TreeNodeContentProvider;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

/**
 * @author tsukano
 *
 */
public class MibTreeView extends ViewPart
{
	public static final String ID = "jp.gr.java_conf.tsukano.snmpfreak.studio.mibtreeview";

	protected TreeViewer viewer;

	protected MibTreeContentProvider contentProvider;

//	protected ICompilationUnit currentTree;

	
	
	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#createPartControl(org.eclipse.swt.widgets.Composite)
	 */
	@Override
	public void createPartControl(Composite parent)
	{
		this.contentProvider = new MibTreeContentProvider();
		this.viewer = new TreeViewer(parent, SWT.MULTI | SWT.H_SCROLL
				| SWT.V_SCROLL);
		this.viewer.setContentProvider(new TreeNodeContentProvider());
//		this.viewer.setContentProvider(this.contentProvider);
		this.viewer.setLabelProvider(new MibTreeLabelProvider());
		
		this.viewer.setInput(makeData());
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#setFocus()
	 */
	@Override
	public void setFocus()
	{
		// TODO Auto-generated method stub

	}
	
	private TreeNode[] makeData()
	{
		TreeNode[] tparent = new TreeNode[2];
		tparent[0] = new TreeNode(new SampleTreeModel("����", 1));
		tparent[1] = new TreeNode(new SampleTreeModel("�������", 1));
		
		TreeNode[] child1 = new TreeNode[2];
		TreeNode[] child2 = new TreeNode[2];

		// ����
		child1[0] = new TreeNode(new SampleTreeModel("�c�ƕ�", 2));
		child1[0].setParent(tparent[0]);

		child1[1] = new TreeNode(new SampleTreeModel("������", 2));
		child1[1].setParent(tparent[0]);
		
		tparent[0].setChildren(child1);
		
		// �������
		child2[0] = new TreeNode(new SampleTreeModel("�V�X�e����", 2));
		child2[0].setParent(tparent[1]);

		child2[1] = new TreeNode(new SampleTreeModel("�J����", 2));
		child2[1].setParent(tparent[1]);
		
		tparent[1].setChildren(child2);
		
		return tparent;
	}
	

}
